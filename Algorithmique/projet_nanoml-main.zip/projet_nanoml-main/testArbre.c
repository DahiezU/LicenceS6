#include <stdio.h>
#include "p_arbre.h"
int main(int argc, char** argv){
    start("exemples/exemple_1.txt");
}