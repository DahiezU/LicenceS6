<h1>Rapport Projet</h1>
<p>
    mon algo consistait à lire caractere par caractere. 
detecter s'il n'y avait pas de balise. 
si c'était le cas je determinais son type. 
j'ajouter la balise dans un arbre. 
si ce n'était pas une balise c'est que c'tait du texte. 
j'ajoutais donc du texte dans l'arbre. 

pour la hierarchie, en fonction des balises ouvrante ou fermante, je montais ou descendais dans l'arbre. 
le but était d'avoir un fichier 'propre'

ensuite je n'avais plus qu'a derouler l'arbre et en fonction du type j'aurai utiliser la grammaire pour savoir quelle balise pouvait etre sous quelle balise... 
</p>